# -*- coding: utf-8 -*-
"""Rebuilds Team16_Steps1to6_Explained.pdf. Rerun after any milestone."""
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Paragraph,
                                Spacer, Table, TableStyle, PageBreak,
                                NextPageTemplate, KeepTogether)
DARK=colors.HexColor("#16212B"); TEAL=colors.HexColor("#0E7C6E")
AMB=colors.HexColor("#B5661C"); TXT=colors.HexColor("#1B2A33")
MUT=colors.HexColor("#5E7180"); CARD=colors.HexColor("#F2F6F8")
GRN=colors.HexColor("#EAF4F2"); WRN=colors.HexColor("#FDF3E7")
LINE=colors.HexColor("#D6E0E6"); W,H=A4
def s_(n,**k):
    d=dict(fontName="Helvetica",fontSize=10,leading=14.5,textColor=TXT,spaceAfter=6); d.update(k)
    return ParagraphStyle(n,**d)
S={"h1":s_("h1",fontName="Helvetica-Bold",fontSize=20,leading=24,textColor=DARK,spaceAfter=6),
 "h2":s_("h2",fontName="Helvetica-Bold",fontSize=14,leading=18,textColor=DARK,spaceBefore=14,spaceAfter=6),
 "h3":s_("h3",fontName="Helvetica-Bold",fontSize=11.5,leading=15,textColor=TEAL,spaceBefore=9,spaceAfter=3),
 "k":s_("k",fontName="Helvetica-Bold",fontSize=8,leading=11,textColor=TEAL,spaceAfter=3),
 "p":s_("p"),"sm":s_("sm",fontSize=9,leading=12.5,textColor=MUT),
 "c":s_("c",fontSize=9,leading=12.5),
 "cb":s_("cb",fontName="Helvetica-Bold",fontSize=9,leading=12.5),
 "cov":s_("cov",fontName="Helvetica-Bold",fontSize=27,leading=32,textColor=colors.white),
 "covs":s_("covs",fontSize=12,leading=17,textColor=colors.HexColor("#AEBFCB"))}
def foot(c,d):
    c.saveState()
    if d.page>1:
        c.setFillColor(MUT); c.setFont("Helvetica",7.5)
        c.drawString(18*mm,12*mm,"Team 16  |  Intent-Based SDN for 5G SLA Enforcement  |  Steps 1-6 Explained")
        c.drawRightString(W-18*mm,12*mm,str(d.page))
    c.restoreState()
def cov(c,d):
    c.saveState(); c.setFillColor(DARK); c.rect(0,0,W,H,fill=1,stroke=0)
    c.setFillColor(TEAL); c.circle(W+8*mm,H-4*mm,55*mm,fill=1,stroke=0)
    c.setFillColor(colors.HexColor("#D98324")); c.circle(W-4*mm,8*mm,28*mm,fill=1,stroke=0)
    c.restoreState()
doc=BaseDocTemplate("Team16_Steps1to6_Explained.pdf",pagesize=A4,leftMargin=18*mm,
  rightMargin=18*mm,topMargin=17*mm,bottomMargin=17*mm,title="Team 16 - Steps 1 to 6 Explained")
fr=Frame(doc.leftMargin,doc.bottomMargin,doc.width,doc.height,id='n')
doc.addPageTemplates([PageTemplate(id='cover',frames=[fr],onPage=cov),
                      PageTemplate(id='body',frames=[fr],onPage=foot)])
def box(items,fill,label=None,lc=TEAL):
    inner=[]
    if label: inner.append(Paragraph(label,ParagraphStyle('l',parent=S["k"],textColor=lc)))
    for i in items: inner.append(Paragraph(i,S["p"]))
    t=Table([[inner]],colWidths=[doc.width])
    t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,-1),fill),("LEFTPADDING",(0,0),(-1,-1),8),
      ("RIGHTPADDING",(0,0),(-1,-1),8),("TOPPADDING",(0,0),(-1,-1),7),
      ("BOTTOMPADDING",(0,0),(-1,-1),7),("VALIGN",(0,0),(-1,-1),"TOP")]))
    return t
def kv(rows,w=38*mm):
    data=[[Paragraph(a,S["cb"]),Paragraph(b,S["c"])] for a,b in rows]
    t=Table(data,colWidths=[w,doc.width-w])
    sty=[("VALIGN",(0,0),(-1,-1),"TOP"),("LEFTPADDING",(0,0),(-1,-1),6),
         ("RIGHTPADDING",(0,0),(-1,-1),6),("TOPPADDING",(0,0),(-1,-1),4),
         ("BOTTOMPADDING",(0,0),(-1,-1),4),("LINEBELOW",(0,0),(-1,-2),0.4,LINE)]
    for i in range(len(rows)):
        if i%2==0: sty.append(("BACKGROUND",(0,i),(-1,i),CARD))
    t.setStyle(TableStyle(sty)); return t
def w5(a,b,c,d,e): return kv([("WHAT",a),("WHY",b),("HOW",c),("WHEN",d),("WHERE",e)],w=22*mm)

F=[Spacer(1,48*mm),Paragraph("Steps 1 to 6, Explained",S["cov"]),Spacer(1,4*mm),
 Paragraph("Intent-Based SDN for 5G Service-Level Agreement Enforcement<br/>"
  "Team 16 &nbsp;|&nbsp; Development Record &nbsp;|&nbsp; 217 tests passing",S["covs"]),
 Spacer(1,12*mm),
 Paragraph("Written for a reader starting from zero. Every step answers what we are doing, "
  "why, how, when and where. Every tool is justified. Nothing is claimed that has not been done.",
  s_("x",fontSize=10.5,leading=15.5,textColor=colors.HexColor("#8FA6B5"))),
 NextPageTemplate('body'),PageBreak()]

F+=[Paragraph("PART 0",S["k"]),Paragraph("The problem, in plain English",S["h1"]),
 Paragraph("A mobile network carries very different traffic over the same wires. A remote-surgery "
  "video feed must never stutter. A file download just needs to be fast on average. A field of "
  "sensors sends a few bytes an hour. They share the same cables and switches.",S["p"]),
 Paragraph("The operator sells promises about quality. A promise looks like: <i>\"this video call "
  "will never be delayed more than 20 milliseconds, will always get at least 20 megabits per "
  "second, and will lose no more than half a percent of packets.\"</i> That is a "
  "<b>Service-Level Agreement</b>, or SLA.",S["p"]),
 Paragraph("The gap: network equipment does not understand promises. A switch understands only "
  "<i>\"packets that look like this go out of port 3.\"</i> Somebody must translate.",S["p"])]
F+=[Paragraph("Three things go wrong today",S["h2"]),kv([
 ("Translation is manual","An engineer converts the promise into switch configuration by hand. Slow, and two engineers do it differently."),
 ("Enforcement is open-loop","Once installed, nothing ever checks the promise is still kept. Traffic shifts, a link degrades, the promise quietly breaks. Nobody notices until a customer complains."),
 ("Requests are accepted blindly","A system that cannot compute remaining capacity will accept a customer it cannot serve, damaging the customers it already had. This is silent failure, and it is the worst of the three."),
],w=42*mm),Spacer(1,4),
 box(["<b>What our system does.</b> You write the promise in a small structured file a computer "
  "can read. The system turns it into switch instructions automatically, watches continuously "
  "whether the promise is kept, and when it starts to break, moves the traffic to a better "
  "route by itself. No human involved."],GRN)]
F+=[Paragraph("Why this is worth building",S["h2"]),
 Paragraph("Systems like this exist in research, but every published one needs equipment a student "
  "cannot get: a specialised radio controller, a server cluster, or a workstation with 500 "
  "gigabytes of memory. Nobody outside those labs can run them, so nobody can check their results.",S["p"]),
 Paragraph("Ours runs on one laptop with 8 gigabytes. <b>We claim no new invention.</b> We claim a "
  "working system anyone can run, measured honestly against explicit comparisons. That is a "
  "legitimate contribution and one we can defend.",S["p"]),PageBreak()]

F+=[Paragraph("PART 1",S["k"]),Paragraph("Every tool we chose, and why",S["h1"]),
 Paragraph("A reasonable question in any review is \"why that one?\" Here is the answer for each.",S["sm"]),Spacer(1,4)]
def tool(n,a,b,c):
    return KeepTogether([Paragraph(n,S["h3"]),
      kv([("What it is",a),("Why we chose it",b),("What we rejected",c)],w=32*mm),Spacer(1,4)])
for args in [
 ("Mininet","Software that pretends to be a whole network of switches and computers inside one laptop. Not a maths simulation - it runs real Linux processes and pushes real packets down virtual wires.",
  "Real switches cost thousands and we have none. Mininet gives genuine network behaviour on a laptop, which is the entire point of the project.",
  "A pure simulator like ns-3. Rejected because it models packets mathematically rather than sending them, so results would not transfer to real equipment."),
 ("Open vSwitch","A network switch implemented in software. Mininet uses it for every switch in our topology.",
  "The same switch software used in real data centres. It speaks OpenFlow properly and supports the traffic-shaping queues we need to enforce bandwidth guarantees.",
  "Mininet's simpler built-in switch. Rejected - it does not support the queueing we need."),
 ("OpenFlow 1.3","The language a controller uses to tell switches what to do. Version 1.3 is the widely supported standard.",
  "It supports multiple flow tables, meters and queues. Version 1.0 does not, and we need those for bandwidth guarantees.",
  "Versions 1.4 and 1.5. Rejected - switch support is patchy and we gain nothing."),
 ("Ryu (the controller)","The central program deciding what every switch should do. Written in Python.",
  "Our whole system is Python, so one language throughout. Ryu has a small API and many tutorials, which matters for a team learning SDN for the first time.",
  "ONOS, a production Java controller. Genuinely more future-proof, but adds a Java toolchain and a steep learning curve to a schedule with no slack. Recorded as our documented fallback if Ryu fails."),
 ("Python 3.9 (pinned)","An older Python version, fixed deliberately.",
  "Ryu depends on a library called eventlet which breaks on Python 3.10 and newer. This is a known, documented failure. Pinning 3.9 inside the container avoids it entirely.",
  "Using the system Python. Rejected - it is 3.10 on modern Ubuntu and Ryu simply will not run."),
 ("Docker","A container: a sealed box holding an operating system and exact versions of every tool.",
  "It makes the project reproducible - anyone, on any machine, gets identical versions. Without it our central claim, that anyone can run this, would be false. It also isolates the fragile Python 3.9 pin from the host machine.",
  "A virtual machine. Heavier and slower; a container is enough."),
 ("NetworkX","A Python library for graphs - dots joined by lines. Our network is a graph: switches are dots, cables are lines.",
  "Route finding is a graph problem. NetworkX gives us tested shortest-path algorithms so we are not debugging our own.",
  "Writing our own graph code. Rejected - it is solved, standard, and not where our effort belongs."),
 ("FastAPI","A library for building a web interface, so an operator can submit a promise over the network instead of editing files on the machine.",
  "Fast to write, validates inputs, and generates its own documentation page - useful in a live demo.",
  "Flask. Similar, but FastAPI's automatic validation saves us work."),
 ("SQLite","A database that lives in a single file. No server to install or run.",
  "It stores intents, measurements and the audit log. Because it is one file we can commit it next to our results, so a reviewer gets the data and the state that produced it. That is the reproducibility argument in practice.",
  "PostgreSQL or MySQL. Rejected - they need a running server, which breaks 'one command to a demo'."),
 ("pytest","The tool that runs our automated tests.",
  "With three people building six interlocking parts, tests are how we discover in seconds - not in November - that someone's change broke someone else's module. We now have 217.",
  "Manual testing. Rejected - it does not scale and it does not catch regressions."),
]: F+=[tool(*args)]
F+=[PageBreak()]

F+=[Paragraph("PART 2",S["k"]),Paragraph("The six steps",S["h1"]),
 Paragraph("The project is 14 one-week steps. Steps 1 to 6 are written, tested and committed. "
  "Each below answers the five questions, then states plainly what exists and what does not.",S["sm"]),Spacer(1,6)]
def step(n,t,d,stat,a,b,c,dd,e,built,honest):
    els=[Paragraph("STEP %d &nbsp;&nbsp;%s &nbsp;&nbsp;|&nbsp;&nbsp; %s"%(n,d,stat),S["k"]),
         Paragraph(t,S["h2"]),w5(a,b,c,dd,e),Spacer(1,5),box(built,GRN,"WHAT NOW EXISTS")]
    if honest: els+=[Spacer(1,3),box([honest],WRN,"WHAT IS NOT TRUE YET",AMB)]
    return els+[Spacer(1,8)]

F+=step(1,"Set up the workshop and freeze the vocabulary","07-13 Aug","DONE - 50 tests",
 "We built the sealed container with exact tool versions, and fixed the exact vocabulary an operator may use to write a promise.",
 "Two reasons. If versions drift the project stops building halfway through and a week disappears. If the vocabulary keeps growing, every new word means new work in all six modules - our own risk list calls this the single biggest threat to finishing.",
 "A Dockerfile pinning Python 3.9, Mininet 2.3.1b4, Open vSwitch 2.17 and Ryu 4.34. The vocabulary is a JSON Schema: a machine-readable rulebook saying exactly which words are legal.",
 "Week 1. It must be first - everything else is built inside this container and speaks this vocabulary.",
 "Dockerfile, requirements.txt, src/intent_manager/schema.json.",
 ["Frozen at <b>five things you may promise</b> (minimum bandwidth, maximum delay, maximum loss, isolation from another customer, links to avoid), <b>three things to do when a promise breaks</b> (reroute, degrade, alert only), and <b>one priority scale</b> 1 to 5.",
  "A validator that accepts a promise or rejects it with a precise pointer to the mistake. It never crashes - tested with numbers, empty files, broken text and wrong shapes.",
  "Eight example promises, one per scenario, and six deliberately broken ones.",
  "<b>50 tests</b>, including tests that fail if anyone widens the vocabulary. The freeze is enforced by the machine, not by a note in a document."],
 "The container has been written but <b>has never been built</b>. <font face='Courier' size='8'>docker compose build</font> has not been run, so the version pins are unproven.")

F+=step(2,"Build the test network","14-20 Aug","DONE - 19 tests",
 "We defined the network our system manages: 7 switches, 8 computers, and the speed and delay of every cable.",
 "We need somewhere to work. Critically we need <b>three completely separate routes</b> between the two important computers. The system's job is to move traffic somewhere better when a promise breaks - with one route there is nowhere to move, and the project cannot be tested at all.",
 "One Python file holds every switch, computer and cable as data. The Mininet script and the tests both read that file, so what the tests check is by construction what gets built.",
 "Week 2, immediately after the workshop is sealed.",
 "topology/topology_spec.py, topology/team16_topo.py.",
 ["Three routes s1 to s7, deliberately unequal so change is visible: <b>northern</b> 100 Mbps / 6 ms, <b>middle</b> 50 Mbps / 15 ms, <b>southern</b> 40 Mbps / 24 ms.",
  "Only the northern route satisfies our test promise; the southern breaks it outright. That asymmetry makes rerouting observable - three identical routes would flatten every measurement.",
  "A test that <b>proves</b> the three routes share no cable, rather than assuming it.",
  "A finding: the original plan's diagram was ambiguous about two cables, and without them only one route exists and the plan's own claim was false. We resolved it, marked both inferred, and a test proves the resolution."],
 "Written and checked as data. <b>The network has never been started.</b> That needs Docker.")

F+=step(3,"Agree the shared language between the six parts","21-27 Aug","DONE - 32 tests",
 "We fixed the exact shapes of data the six modules pass each other, before writing any of them.",
 "Three people build six interlocking parts at once. If one person's idea of a 'path' differs from another's, nothing fits, and we would find out in November. Our risk register names this and names this step as the fix.",
 "One folder, src/common, holding the shared shapes: an intent, a path, a link, a measurement, an admission decision. Plus the database layout, the message format between modules, and the audit log.",
 "Week 3. Deliberately before any module is written. The step that looks like a delay and is not.",
 "src/common/models.py, events.py, db.py, audit.py.",
 ["The anti-oscillation rule lives in <b>exactly one place</b>, so two modules cannot disagree about whether it is safe to move traffic again.",
  "A decision object that <b>refuses to exist without a reason</b>. Constructing a rejection with an empty explanation raises an error. That enforces 'no silent failures' at the language level.",
  "A database recording <b>every</b> path ever installed rather than overwriting, so a reroute is two rows. That makes 'how many times did it move?' countable directly from the data.",
  "An audit log recording the full chain: what we measured, what was promised, what we decided, what we did."],None)

F+=step(4,"Accept a promise and work out a route","28 Aug - 03 Sep","DONE - 32 tests, demonstrable",
 "The system takes a written promise over the network and works out a route through the switches that satisfies it.",
 "The first step where the system does something a person can see. Until now it was foundations.",
 "Three pieces. Yen's algorithm finds the three best routes. A pruning stage discards any route that breaks the promise, <b>recording a plain-English reason for each rejection</b>. A selection stage picks the best survivor, deterministically so runs repeat.",
 "Week 4, once the shared language existed.",
 "src/pathing/, src/intent_manager/api.py.",
 ["Submit a promise, get back a route. Live, in about half a millisecond.",
  "Refusals explain themselves: <font face='Courier' size='8'>exceeds max_latency_ms: 24 &gt; 20</font> and <font face='Courier' size='8'>insufficient bandwidth: 100 &lt; 500</font>.",
  "A web interface to submit, list, inspect and withdraw promises.",
  "A runnable demo: <font face='Courier' size='8'>python demo_st4.py</font>",
  "Two real bugs caught by the new tests: the route finder crashed on an unknown address instead of explaining itself, and the database would have failed the moment the web server handled a second request. The second would have broken the live system, not just a test."],None)

F+=step(5,"Turn the route into real switch instructions","04-10 Sep","DONE - 39 tests, not run live",
 "Code that converts a chosen route into actual OpenFlow instructions and bandwidth-limiting queues on the switches.",
 "A route on paper moves no packets. This is where the system stops being a calculator and becomes a network controller.",
 "Three parts: a translator turning a route into per-switch instructions; a queue manager creating traffic-shaping queues that enforce the bandwidth guarantee; and the Ryu controller application that talks to the switches.",
 "Week 5, after routes could be computed.",
 "src/enforcement/flowmod.py, queues.py, controller.py.",
 ["Instructions generated for every switch on the route, in both directions.",
  "Each promise gets a unique identifying tag, so its instructions can be found and removed later.",
  "Bandwidth guarantees converted into queue configuration, in bits per second.",
  "<b>39 tests</b> added since the last version of this document. They check the instruction shapes without needing a live switch: that the IPv4 marker is always set (an instruction missing it installs but never matches - the most common failure in this area), that ports come only from the discovered map and are never invented, and that queue commands use the right units."],
 "The tests check the <b>shape</b> of the instructions, not their effect. The code has still <b>never run against a real switch</b>. Until Docker is built and a switch accepts them, treat step 5 as unproven in the field.")

F+=step(6,"Measure whether the promise is actually being kept","11-17 Sep","DONE - 45 tests",
 "Continuously measure the real delay, jitter, loss and throughput each promise receives, and decide when a promise has genuinely been broken.",
 "Without measurement the system is open-loop: it sets things up and never checks. Measurement is what makes it a control system rather than a configuration script. It is the half of the project that is actually hard.",
 "Two sources of numbers, then four filters. Counters read off the switches once a second give loss and throughput; small timestamped test packets give delay and jitter. Then: averaging so one noisy reading is ignored; a dead-band so a value hovering at the limit does not flicker; a rule requiring several bad readings in a row; and a hold-off timer so the system does not react twice in quick succession.",
 "Week 6. It needs step 5's installed routes to have something to measure.",
 "src/telemetry/detector.py, collector.py, probes.py.",
 ["The deciding logic is <b>completely separate</b> from the measuring, so it can be tested by feeding it invented numbers - no network required. That design decision is why step 6 has 45 tests while step 5 has none that prove behaviour.",
  "All four damping filters implemented, each with the specific failure it prevents recorded in a comment.",
  "A replay helper that pushes a scripted list of readings through at a simulated rate, so a ten-minute scenario runs instantly and identically every time.",
  "A fake measurement source with the same interface as the real one, so tests never touch a network.",
  "<b>45 tests</b>, including proof that a single bad reading does not trigger, that a value sitting exactly on the limit emits nothing, and that recovery requires clearing the far side of the dead-band."],
 "The <b>collector</b> - the part that reads real numbers off real switches - has the same status as step 5: written, unit-tested for shape, never run against a live datapath.")

F+=[PageBreak(),Paragraph("PART 3",S["k"]),Paragraph("Honest status",S["h1"]),
 Paragraph("Stated plainly, because being caught overclaiming costs more than admitting a gap.",S["sm"]),Spacer(1,4),
 kv([
 ("Steps done","6 of 14. Roughly 43 percent by count."),
 ("Tests passing","<b>217</b>, automatically, in under two seconds. Breakdown: intent validation 50, enforcement 39, telemetry 45, shared interfaces 32, routing and API 32, topology 19."),
 ("What genuinely works","A promise can be written, validated, rejected with reasons if malformed, converted into a route satisfying its constraints, stored, and served over a web interface. Measurements can be judged against a promise with all four damping filters. All demonstrable now, on any machine, with no special hardware."),
 ("What does NOT work yet","Nothing has touched a real network. Not one packet has moved. The container has never been built. The switch instructions of step 5 and the counter reader of step 6 are unproven against live equipment. Above all, <b>the loop is not closed</b>: a detected breach does not yet cause a reroute."),
 ("The single blocking task","Run <font face='Courier' size='8'>docker compose build</font>. Until it succeeds, steps 2, 5 and half of 6 are theory."),
 ],w=42*mm),Spacer(1,6),
 box(["<b>How to describe this to an examiner.</b> \"Six of fourteen steps, 217 tests passing. "
  "A written promise becomes a validated, constraint-satisfying route, and measurements are judged "
  "against it with proper damping. The enforcement and collection code is written and unit-tested "
  "but not yet verified against a live switch. Closing the loop is the next step.\" "
  "Do not say more. It is enough, and all of it is true."],WRN)]

F+=[Paragraph("The one thing that is now missing",S["h2"]),
 Paragraph("Step 6 can detect that a promise is broken. Step 5 can install a route. <b>Nothing "
  "yet joins them.</b> The detector raises an alarm and no one is listening.",S["p"]),
 Paragraph("Step 7 is that single connection - and it is the whole project in one step. It is "
  "what the demo shows and what the marks follow. The brief for it is written and waiting in "
  "<font face='Courier' size='8'>prompts/ST-07_close_the_loop.md</font>.",S["p"])]
F+=[Paragraph("What the next three steps add",S["h2"]),kv([
 ("Step 7","<b>The closed loop.</b> A measured breach automatically triggers a new route, avoiding the links that just failed. This is the project's entire point."),
 ("Step 8","Admission control. Before accepting a new promise, check there is room. If not, refuse with a reason or displace something less important - never accept and fail silently."),
 ("Step 9","Preemption and tuning. Priority-based displacement, and tuning the damping so the oscillation graph can be produced with the filters on and off."),
],w=22*mm)]

F+=[Paragraph("Handover",S["h2"]),
 Paragraph("The project is packaged for the team. <font face='Courier' size='8'>SETUP.md</font> "
  "walks a newcomer through setup, deliberately putting the no-Docker path first because it needs "
  "no root and still exercises everything through step 6. "
  "<font face='Courier' size='8'>tools/verify_setup.py</font> checks a machine and fails loudly "
  "with a fix hint. <font face='Courier' size='8'>docs/HANDOVER.md</font> is the one-page briefing. "
  "A distributable zip is in <font face='Courier' size='8'>dist/</font> with a checksum.",S["p"])]

F+=[PageBreak(),Paragraph("PART 4",S["k"]),Paragraph("Words you will need",S["h1"]),
 Paragraph("Learn these well enough to define in one sentence if interrupted.",S["sm"]),Spacer(1,4),
 kv([
 ("SDN","Software-Defined Networking. Normally every switch decides for itself where to send packets. In SDN you take that decision away and give it to one central program."),
 ("Controller","That central program. Ours is Ryu."),
 ("OpenFlow","The language the controller uses to talk to switches."),
 ("Flow rule","One instruction inside a switch: packets that look like this go out of that port. A switch holds thousands."),
 ("Intent","The promise, written in a structured file a computer can read."),
 ("SLA","Service-Level Agreement. The business promise about quality. Our intents are machine-readable SLAs."),
 ("Closed loop","Measure, notice something is wrong, fix it, measure again - with no human involved. Open loop means you set it up and never check."),
 ("Telemetry","The measurements collected while running: delay, jitter, loss, throughput."),
 ("Jitter","How much the delay wobbles. A steady 20 ms is fine for a video call; bouncing between 5 and 40 ms is not."),
 ("EWMA","Exponentially weighted moving average. A running average that weights recent readings more heavily, so one odd sample does not move it much."),
 ("Hysteresis","A deliberate gap between the level that triggers an alarm and the level that clears it, so a value on the boundary does not flicker on and off."),
 ("Dwell timer","A hold-off. Having just moved traffic, do not move it again for N seconds however bad it looks."),
 ("Counter delta","The difference between two readings of a switch counter. Rates must be computed from differences, never from the absolute value."),
 ("Admission control","Before accepting a new promise, check there is capacity. If not, refuse with a reason rather than accepting and failing silently."),
 ("Link-disjoint","Two routes sharing no cable. If one cable breaks, the other route is unaffected."),
 ("Baseline","A deliberately weaker version you compare against, so you can prove your system helps."),
 ("URLLC / eMBB / mMTC","The three 5G traffic types: ultra-reliable low-latency, high-bandwidth, and huge numbers of small sensors."),
 ],w=32*mm)]
doc.build(F); print("BUILT")
